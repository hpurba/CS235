#ifndef MYVECTOR_H
#define MYVECTOR_H
#include "Deque.h"

using namespace std;

template <typename T>
class MyVector
{
private:
	DeQue<T> vector_;

public:
	MyVector() {}
	~MyVector() {}
	void push_back(T& data);
	void pop_back();
	size_t size();
	T& at(size_t index);
	string toString()const;
};

template<typename T>
void MyVector<T>::push_back(T& data)
{
	vector_.push_back(data);
}

template<typename T>
void MyVector<T>::pop_back()
{
	vector_.pop_back();
}

template<typename T>
size_t MyVector<T>::size()
{
	return vector_.size();
}

template<typename T>
T& MyVector<T>::at(size_t index)
{
	return vector_.at(index);
}

template<typename T>
string MyVector<T>::toString()const
{
	string sOm = "";
	return sOm;
}
#endif // MYVECTOR_H
