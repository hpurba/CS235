#ifndef MYSTATION_H
#define MYSTATION_H

#include "MyStack.h"
#include "MyQueue.h"
#include "MyVector.h"
#include <sstream>
#include <string>

template<typename T>
class MyStation
{
private:
	MyVector<T> train_;		//Train Vector
	MyStack<T> stack_;		//Stack house
	MyQueue<T> queue_;		//Queue house
	T turnTableCar;			//Turntable
	bool empty;				//Indicates Turntable empty
public:
	MyStation();
	~MyStation();

	// Add:
	string addCar(const T& car);
	string addQueue();
	string addStack();

	// Remove:
	string removeCar();
	string removeQueue();
	string removeStack();

	// Top:
	string topCar();
	string topQueue();
	string topStack();

	// Size
	string sizeQueue();
	string sizeStack();
	
	
	// Find, toString function
	string find(T item);
	string toString();
};

// FUNCTIONS

template<typename T>
MyStation<T>::MyStation()
{
	empty = true;
}

template<typename T>
MyStation<T>::~MyStation()
{

}

//Add Train car to turntable
template<typename T>
string MyStation<T>::addCar(const T& car)
{
	if (empty)
	{
		turnTableCar = car;
		empty = false;
		return "OK";
	}
	else
	{
		return "Turntable occupied!";
	}
}
//Add Train car to Queue
template<typename T>
string MyStation<T>::addQueue()
{
	if (empty)
	{
		return "Turntable empty!";
	}
	else
		queue_.push(turnTableCar);
		empty = true;
		return "OK";
}
//Add Train car to Queue
template<typename T>
string MyStation<T>::addStack()
{
	if (empty)
	{
		return "Turntable empty!";
	}
	else
		stack_.push(turnTableCar);
		empty = true;
		return "OK";
}

//Remove Train car from turntable
template<typename T>
string MyStation<T>::removeCar()
{
	if (empty)
		return "Turntable empty!";
	else
	{
		train_.push_back(turnTableCar);
		empty = true;
		return "OK";
	}
}

//Remove Train car from Queue
template<typename T>
string MyStation<T>::removeQueue()
{
	if (queue_.size() == 0)
		return "Queue empty!";
	else
	{
		if (empty)
		{
			turnTableCar = queue_.top();
			queue_.pop();
			empty = false;
			return "OK";
		}
		else
		{
			return "Turntable occupied!";
		}
	}
}
//Remove Train car from Stack
template<typename T>
string MyStation<T>::removeStack()
{
	if (stack_.size() == 0)
		return "Stack empty!";
	else
	{
		if (empty)
		{
			turnTableCar = stack_.top();
			stack_.pop();
			empty = false;
			return "OK";
		}
		else
		{
			return "Turntable occupied!";
		}
	}
}

// Top:
template<typename T>
string MyStation<T>::topCar()
{
	if (!empty)
	{
		stringstream s;
		s << turnTableCar;
		return s.str();
	}
	else
		return "Turntable empty!";
}

template<typename T>
string MyStation<T>::topQueue()
{
	if (queue_.size() > 0)
	{
		stringstream s;
		s << queue_.top();
		return s.str();
	}
	else
		return "Queue empty!";
}

template<typename T>
string MyStation<T>::topStack()
{
	if (stack_.size() > 0)
	{
		stringstream s;
		s << stack_.top();
		return s.str();
	}
	else
	{
		return "Stack empty!";
	}
}

// Size
template<typename T>
string MyStation<T>::sizeQueue()
{
	stringstream s;
	s << queue_.size();
	return s.str();
}

template<typename T>
string MyStation<T>::sizeStack()
{
	stringstream s;
	s << stack_.size();
	return s.str();
}

//FIND
template<typename T>
string MyStation<T>::find(T item)
{
	stringstream s;
	bool found = false;
	unsigned int i = 0;

	// In Turntable
	if (turnTableCar == item)
	{
		found = true;
		s << "Turntable";
	}

	// Stack
	if (!found)
	{
		i = 0;
		for (; i < stack_.size(); i++)
		{
			if (stack_.at(i) == item)
			{
				s << "Stack[" << i << "]";
				found = true;
				break;
			}

		}
	}

	// Queue
	if (!found)
	{
		i = 0;
		for (; i < queue_.size(); i++)
		{
			if (queue_.at(i) == item)
			{
				s << "Queue[" << i << "]";
				found = true;
				break;
			}
		}
	}

	// Train
	if (!found)
	{
		i = 0;
		for (; i < train_.size(); i++)
		{
			if (train_.at(i) == item)
			{
				s << "Train[" << i << "]";
				found = true;
				break;
			}
		}
	}

	if (!found)
	{
		s << "Not Found!";
	}

	return s.str();
}

// Train function. toString
template<typename T>
string MyStation<T>::toString()
{
	stringstream s;
	for (unsigned int i = 0; i < train_.size(); i++)
	{
		s << train_.at(i) << " ";
	}
	return s.str();
}

#endif // MYSTATION_H